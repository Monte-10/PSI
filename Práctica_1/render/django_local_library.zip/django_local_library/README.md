# django_local_library
Local Library website written in Django
